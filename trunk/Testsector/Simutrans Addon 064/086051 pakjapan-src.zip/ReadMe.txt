Japanese Simutrans Scenario 64x64
===============================

Version 0.2

Please copy the folder "PakJap" to your simutrans folder. Then 
edit "config\simuconf.tab":
change
"pak_file_path = pak"
to
"pak_file_path = PakJap"

You may also change the starting year to 1940:
"starting_year = 1940"
and switch the timeline on(=1) (or off=0):
use_timeline = 0

Finally, to use japanese city names, copy either "cities.prefectures.txt"
or "citylist-small.txt" to "text\citylist-en.txt" (or whatever language 
you use.

The graphics are from divers places, some of them also by myself. 
For most of them the LGPL-licence applies. You can find the copyright
list (not yet finished) in the fiel Copyright.txt.

For any messages or suggestions (like better balance of industries)
please mail me:
markus@pristovsek.de

Have fun!