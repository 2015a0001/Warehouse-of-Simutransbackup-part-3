#! /bin/bash

# Hajo: some tiles are needed in size 64x64

cp pak64/menu.MainMenu.pak  pak128
cp pak64/symbol.Flags.pak   pak128
cp pak64/symbol.Logo.pak    pak128
cp pak64/menu.*.pak         pak128
