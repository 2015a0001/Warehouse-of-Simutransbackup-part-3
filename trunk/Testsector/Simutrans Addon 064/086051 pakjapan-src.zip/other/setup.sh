#! /bin/bash

rm images;
rm pak;
 
if [ "$1" = "128" ]; then
    ln -s images128 images
    ln -s pak128 pak
else
    ln -s images64 images
    ln -s pak64 pak
fi  
